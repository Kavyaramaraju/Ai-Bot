from langgraph import LangGraph, Node

class SummarizeNode(Node):
    def run(self, inputs):
        context = inputs.get('context')
        query = inputs.get('query')
        return {"summary": f"Summarized data for query: {query}"}

def create_workflow():
    graph = LangGraph()
    graph.add_node('summarize', SummarizeNode())
    return graph
