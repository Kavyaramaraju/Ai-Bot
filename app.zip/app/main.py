from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from database import init_db, get_session
from models import Product, Supplier
from workflow import create_workflow

app = FastAPI()

workflow = create_workflow()

@app.on_event("startup")
def startup():
    init_db()

@app.post("/query")
def query_database(query: str, session: Session = Depends(get_session)):
    results = session.query(Product).filter(Product.name.ilike(f"%{query}%")).all()
    response = workflow.run({"query": query, "context": results})
    return {"answer": response["summary"]}
